@echo off
cd /d "%~dp0"
python ria.py
if errorlevel 1 pause
