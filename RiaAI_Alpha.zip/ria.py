r"""
Ріас — локальний ІІ-компаньйон (тестова версія, без зору)

Ctrl+Alt+X  — показати / сховати
Enter       — відправити
Esc         — сховати

Потрібно:
    pip install requests keyboard pillow
    ollama pull qwen3:4b-instruct    # мозок (чат + виклик інструментів), без «роздумів»
    ollama pull qwen2.5-coder:7b     # необов'язково: пише код у файли (CODE_MODEL)
Картинки персонажа лежать поруч зі скриптом: ria_idle.png (очікує), ria_thinking.png (думає),
ria_speaking.png + ria_speaking2.png (говорить, кадри чергуються). Усі одного розміру.
Якщо якоїсь немає — береться ria_idle.png або ria.png.
Усі файли, які створює Ріас, лежать у папці  workspace  поруч зі скриптом
Програми, які Ріас додала до свого списку за твоїм проханням, зберігаються у файлі  apps.json  поруч зі скриптом
"""
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import font as tkfont
import webbrowser
from pathlib import Path
from tkinter import messagebox

import keyboard
import requests
from PIL import Image, ImageTk

# ---------------- НАЛАШТУВАННЯ ----------------
OLLAMA_URL = "http://localhost:11434/api/chat"
CHAT_MODEL = "qwen3:4b-instruct"  # версія БЕЗ «роздумів» (швидка); звичайний qwen3:4b завжди довго думає
CODE_MODEL = ""  # напр. "qwen2.5-coder:7b"; "" = вимкнено, тоді код пише сама CHAT_MODEL
HOTKEY = "ctrl+alt+x"
CHAR_IMAGE = Path(__file__).with_name("ria.png")

# Робоча папка лежить поруч зі скриптом (Ria/workspace) — тож працює на будь-якому диску
WORKSPACE = (Path(__file__).resolve().parent / "workspace").resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)

# Білий список програм: що Ріас МОЖЕ відкривати. Додавай свої.
APPS = {
    "блокнот": "notepad.exe",
    "калькулятор": "calc.exe",
    "провідник": "explorer.exe",
    "диспетчер задач": "taskmgr.exe",
    "paint": "mspaint.exe",
    # "steam": r"C:\Program Files (x86)\Steam\steam.exe",
}

# Програми, які Ріас додає сама за твоїм проханням (зберігаються між запусками)
APPS_FILE = WORKSPACE.parent / "apps.json"
CUSTOM_APPS: dict[str, str] = {}


def _load_custom_apps():
    try:
        data = json.loads(APPS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            for k, v in data.items():
                if isinstance(k, str) and isinstance(v, str):
                    CUSTOM_APPS[k.strip().lower()] = v
    except (OSError, ValueError):
        pass
    APPS.update(CUSTOM_APPS)


def _save_custom_apps():
    APPS_FILE.parent.mkdir(parents=True, exist_ok=True)
    APPS_FILE.write_text(json.dumps(CUSTOM_APPS, ensure_ascii=False, indent=2), encoding="utf-8")


_load_custom_apps()

SYSTEM_PROMPT = (
    "Ти — Ріас Ґреморі з аніме «Старшокласники DxD», але тут ти особиста помічниця на комп'ютері користувача. "
    "Характер: аристократична, витончена й спокійна, впевнена в собі, тепла й турботлива; "
    "трохи грайлива й дражлива, любиш легкий гумор і м'які підколки. Користувача цінуєш і ставишся до нього з теплотою. "
    "Ти слухняна: охоче виконуєш його прохання без заперечень і повчань. "
    "Якщо щось неможливо або небезпечно — чемно й коротко поясни чому, без нотацій. "
    "Іноді можеш додати легкий жест чи усмішку (наприклад «~» наприкінці фрази), але в міру, без надмірності. "
    "Відповідай коротко (1–3 речення) мовою користувача: українською або російською, не англійською. "
    "Ніколи не показуй свої міркування, пиши лише готову відповідь. "
    "Програми відкривай через open_app, сайти через open_url. "
    "Якщо просять додати програму до списку: спершу find_app за назвою; якщо знайшлася одна — виклич add_app "
    "з цією назвою і шляхом (користувач сам підтвердить у вікні); якщо нічого не знайшла — попроси повний шлях "
    "до .exe або ярлика. Якщо просять відкрити програму, якої немає в списку, запропонуй додати її. "
    "Файли й код створюй у робочій папці: create_file (коли ти сама знаєш весь вміст) "
    "або generate_code_file (коли треба написати програму за описом). "
    "Запускай код (run_python) тільки якщо користувач про це попросив. "
    "Після дії коротко скажи, що саме зроблено. Не вигадуй результатів."
)


def _tool(name, desc, props, required):
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": {
                "type": "object",
                "properties": {k: {"type": "string", "description": v} for k, v in props.items()},
                "required": required,
            },
        },
    }


def build_tools() -> list[dict]:
    """Збирається щоразу, щоб у описі був актуальний список програм (вони можуть додаватися на ходу)."""
    tools = [
        _tool("open_app", "Відкрити програму зі списку дозволених: " + ", ".join(APPS),
              {"name": "Назва програми"}, ["name"]),
        _tool("list_apps", "Показати список програм, які можна відкривати", {}, []),
        _tool("find_app", "Знайти програму на ПК за назвою (меню «Пуск» і робочий стіл), щоб потім додати її у список",
              {"query": "Назва програми, напр. steam"}, ["query"]),
        _tool("add_app", "Додати програму до списку дозволених (користувач підтверджує у вікні)",
              {"name": "Коротка назва, якою її називатимуть", "path": "Повний шлях до .exe, .lnk або .url"},
              ["name", "path"]),
        _tool("remove_app", "Прибрати програму зі списку, яку раніше додали", {"name": "Назва програми"}, ["name"]),
        _tool("open_url", "Відкрити сайт у браузері", {"url": "Адреса https://..."}, ["url"]),
        _tool("create_file", "Створити або перезаписати файл у робочій папці",
              {"path": "Відносний шлях, напр. hello.py", "content": "Повний вміст файлу"}, ["path", "content"]),
        _tool("read_file", "Прочитати файл із робочої папки", {"path": "Відносний шлях"}, ["path"]),
        _tool("list_files", "Показати файли в робочій папці", {}, []),
        _tool("open_workspace", "Відкрити робочу папку у провіднику", {}, []),
        _tool("run_python", "Запустити .py файл з робочої папки (користувач підтверджує)",
              {"path": "Відносний шлях до .py"}, ["path"]),
    ]
    if CODE_MODEL:
        tools.append(
            _tool("generate_code_file",
                  "Написати код за описом спеціальною моделлю для коду і зберегти у файл",
                  {"path": "Відносний шлях, напр. snake.py", "task": "Докладний опис, що має робити код"},
                  ["path", "task"])
        )
    return tools


# Підставляється вікном: функція, яка питає користувача «так/ні» (працює з іншого потоку)
confirm_fn = lambda text: False  # noqa: E731


# ---------------- ІНСТРУМЕНТИ ----------------
def _safe(rel: str) -> Path:
    p = (WORKSPACE / rel).resolve()
    if not p.is_relative_to(WORKSPACE):
        raise ValueError("Шлях виходить за межі робочої папки")
    return p


def _strip_fences(s: str) -> str:
    s = s.strip()
    if s.startswith("```"):
        s = s.split("\n", 1)[1] if "\n" in s else ""
        s = s.rstrip()
        if s.endswith("```"):
            s = s[:-3]
    return s.strip()


def _resolve_app(name: str) -> str | None:
    key = name.strip().lower()
    if key in APPS:
        return key
    matches = [k for k in APPS if key and (key in k or k in key)]
    return matches[0] if len(matches) == 1 else None


def open_app(name: str) -> str:
    key = _resolve_app(name)
    if not key:
        return f"'{name}' немає в списку дозволених. Доступні: {', '.join(APPS)}"
    os.startfile(APPS[key])  # тільки Windows
    return f"Запущено: {key}"


def list_apps() -> str:
    return ", ".join(APPS)


def find_app(query: str) -> str:
    q = query.strip().lower()
    if not q:
        return "Вкажи, що шукати."
    roots = []
    if os.environ.get("ProgramData"):
        roots.append(Path(os.environ["ProgramData"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    if os.environ.get("APPDATA"):
        roots.append(Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    roots += [Path.home() / "Desktop", Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "Desktop"]
    found, seen = [], set()
    for root in roots:
        if not root.is_dir():
            continue
        for f in root.rglob("*"):
            if f.suffix.lower() not in {".lnk", ".exe", ".url"} or q not in f.stem.lower():
                continue
            if re.search(r"uninstall|видал|удал", f.stem, re.I) or str(f).lower() in seen:
                continue
            seen.add(str(f).lower())
            found.append(f"{f.stem} → {f}")
            if len(found) >= 8:
                break
        if len(found) >= 8:
            break
    if not found:
        return ("Нічого не знайшла. Попроси користувача дати повний шлях до .exe або ярлика "
                "(Shift + права кнопка на файлі → «Копіювати як шлях»).")
    return "\n".join(found)


def add_app(name: str, path: str) -> str:
    key = name.strip().lower()
    if not key:
        return "Потрібна назва програми."
    p = Path(path.strip().strip('"'))
    if not p.is_file() or p.suffix.lower() not in {".exe", ".lnk", ".url"}:
        return "Файл не знайдено, або це не .exe / .lnk / .url."
    replaced = key in APPS
    if not confirm_fn(f"{'Замінити' if replaced else 'Додати'} програму у списку дозволених?\n\n"
                      f"Назва: {key}\nШлях: {p}"):
        return "Користувач відмовився."
    CUSTOM_APPS[key] = str(p)
    APPS[key] = str(p)
    _save_custom_apps()
    return f"Додано до списку: {key}"


def remove_app(name: str) -> str:
    key = name.strip().lower()
    if key in CUSTOM_APPS:
        del CUSTOM_APPS[key]
        APPS.pop(key, None)
        _save_custom_apps()
        return f"Прибрано зі списку: {key}"
    if key in APPS:
        return "Це вбудована програма, її можна прибрати тільки в коді (блок APPS)."
    return f"'{name}' немає в списку."


def open_url(url: str) -> str:
    if not url.lower().startswith(("http://", "https://")):
        return "Дозволені тільки адреси http/https."
    webbrowser.open(url)
    return f"Відкрито: {url}"


def create_file(path: str, content: str) -> str:
    p = _safe(path)
    existed = p.exists()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return f"{'Оновлено' if existed else 'Створено'}: {p.relative_to(WORKSPACE)} ({len(content)} символів)"


def read_file(path: str) -> str:
    p = _safe(path)
    if not p.is_file():
        return "Такого файлу немає."
    return p.read_text(encoding="utf-8", errors="replace")[:4000]


def list_files() -> str:
    files = [str(f.relative_to(WORKSPACE)) for f in WORKSPACE.rglob("*") if f.is_file()]
    return "\n".join(files[:100]) or "Робоча папка порожня."


def open_workspace() -> str:
    os.startfile(WORKSPACE)
    return f"Відкрито папку {WORKSPACE}"


def run_python(path: str) -> str:
    p = _safe(path)
    if p.suffix != ".py" or not p.is_file():
        return "Це не існуючий .py файл."
    preview = p.read_text(encoding="utf-8", errors="replace")[:500]
    if not confirm_fn(f"Запустити {p.name}?\n\n{preview}"):
        return "Користувач відмовився запускати."
    try:
        r = subprocess.run([sys.executable, str(p)], cwd=WORKSPACE, capture_output=True,
                           text=True, timeout=30, encoding="utf-8", errors="replace")
        out = (r.stdout + r.stderr).strip()
        return (out[:2000] or "(без виводу)") + f"\n[код завершення {r.returncode}]"
    except subprocess.TimeoutExpired:
        return "Перервано: працює довше 30 секунд."


def generate_code_file(path: str, task: str) -> str:
    p = _safe(path)
    r = requests.post(
        OLLAMA_URL,
        json={
            "model": CODE_MODEL,
            "stream": False,
            "messages": [
                {"role": "system", "content": "Ти досвідчений програміст. Відповідай ТІЛЬКИ кодом файлу, "
                                              "без пояснень і без markdown-огорож."},
                {"role": "user", "content": f"Файл: {p.name}\nЗавдання: {task}"},
            ],
        },
        timeout=600,
    )
    r.raise_for_status()
    code = _strip_fences(r.json()["message"]["content"])
    return create_file(path, code)


TOOL_FUNCS = {
    "open_app": open_app, "list_apps": list_apps, "find_app": find_app, "add_app": add_app,
    "remove_app": remove_app, "open_url": open_url, "create_file": create_file,
    "read_file": read_file, "list_files": list_files, "open_workspace": open_workspace,
    "run_python": run_python, "generate_code_file": generate_code_file,
}


def run_tool(name: str, args: dict) -> str:
    fn = TOOL_FUNCS.get(name)
    if not fn:
        return f"Невідомий інструмент: {name}"
    try:
        return fn(**args)
    except Exception as e:
        return f"Помилка інструмента {name}: {e}"


# ---------------- МОЗОК (Ollama) ----------------
history: list[dict] = []


def clean_reply(text: str) -> str:
    """Прибирає «роздуми» Qwen3, якщо вони потрапили у відповідь."""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    if "</think>" in text:
        text = text.split("</think>")[-1]
    return text.strip()


def ask(user_text: str) -> str:
    history.append({"role": "user", "content": user_text})
    msgs = [{"role": "system", "content": SYSTEM_PROMPT}] + history[-20:]
    try:
        for _ in range(5):  # максимум 5 кроків інструментів на одне повідомлення
            r = requests.post(
                OLLAMA_URL,
                json={
                    "model": CHAT_MODEL,
                    "messages": msgs,
                    "tools": build_tools(),
                    "stream": False,
                    "keep_alive": "30m",  # тримати модель у пам'яті, щоб не вантажити щоразу
                    "options": {"temperature": 0.7, "top_p": 0.8, "top_k": 20, "num_ctx": 8192},
                },
                timeout=600,
            )
            r.raise_for_status()
            m = r.json()["message"]
            msgs.append(m)
            calls = m.get("tool_calls")
            if not calls:
                text = clean_reply(m.get("content") or "") or "…"
                history.append({"role": "assistant", "content": text})
                return text
            for c in calls:
                fn = c["function"]["name"]
                args = c["function"].get("arguments") or {}
                msgs.append({"role": "tool", "tool_name": fn, "content": run_tool(fn, args)})
        return "Забагато кроків, не вийшло завершити."
    except requests.ConnectionError:
        return "Ollama не запущений. Запусти його і спробуй ще раз."
    except Exception as e:
        return f"Помилка: {e}"


# ---------------- ВІКНО ----------------
W = 640  # ширина вікна (і рамки з текстом)
TRANSPARENT = "#ff00ff"
STATES = ("idle", "thinking", "speaking", "speaking2")


def state_path(name: str) -> Path:
    return Path(__file__).with_name(f"ria_{name}.png")


class Ria:
    def __init__(self):
        global confirm_fn
        self.q: queue.Queue = queue.Queue()
        self.last_reply = ""
        self._drag = (0, 0)
        self._speak_job = None
        self._speak_until = 0.0

        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=TRANSPARENT)
        self.root.attributes("-transparentcolor", TRANSPARENT)
        self.bfont = tkfont.Font(family="Segoe UI", size=13)

        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.char_h = min(520, int(sh * 0.45))                           # висота персонажа
        self.max_bubble_h = max(200, int(sh * 0.85) - self.char_h - 90)  # макс. висота рамки
        self.bubble_h = 160

        # нижня панель (пакуємо першою, щоб вона ніколи не обрізалась)
        bar = tk.Frame(self.root, bg=TRANSPARENT)
        bar.pack(side="bottom", fill="x", padx=20, pady=8)
        self.entry = tk.Entry(bar, font=("Segoe UI", 12), bg="white", relief="solid", bd=2)
        self.entry.pack(side="left", fill="x", expand=True, ipady=3)
        self.entry.bind("<Return>", self.on_submit)
        self.entry.bind("<Escape>", lambda e: self.root.withdraw())

        self.canvas = tk.Canvas(self.root, width=W, height=self.bubble_h, bg=TRANSPARENT, highlightthickness=0)
        self.canvas.pack(side="top")
        self.char = tk.Label(self.root, bg=TRANSPARENT)
        self.char.pack(side="top")
        self._load_character()

        # текст відповіді — звичайне поле Text (тільки для читання): його можна виділяти мишкою
        self.txt = tk.Text(self.canvas, wrap="word", bg="white", fg="black", relief="flat", bd=0,
                           highlightthickness=0, padx=0, pady=0, font=self.bfont, cursor="xterm",
                           state="disabled", exportselection=False,
                           selectbackground="#9ec5ff", selectforeground="black",
                           inactiveselectbackground="#cfe2ff")
        self.txt.bind("<Button-1>", lambda e: (self.root.focus_force(), self.txt.focus_set()))
        self.txt.bind("<Control-a>", self._select_all)
        self.txt.bind("<Control-c>", lambda e: (self.copy_selection(), "break")[1])
        self.menu = tk.Menu(self.root, tearoff=0)
        self.menu.add_command(label="Копіювати виділене", command=self.copy_selection)
        self.menu.add_command(label="Копіювати все", command=self.copy_all)
        self.txt.bind("<Button-3>", self._popup_menu)
        self.canvas.bind("<Button-3>", self._popup_menu)

        # перетягування вікна: за рамку, персонажа або порожню частину біля поля вводу
        for w in (self.canvas, self.char, bar):
            w.bind("<ButtonPress-1>", self._start_drag)
            w.bind("<B1-Motion>", self._on_drag)

        # початкова позиція — правий нижній кут
        self.root.update_idletasks()
        total = self.root.winfo_reqheight()
        self.x, self.y = sw - W - 20, sh - total - 60
        self.root.geometry(f"+{self.x}+{self.y}")

        confirm_fn = self.confirm
        self.say("Привіт! Я Ріас. Ctrl+Alt+X — покликати або сховати. Мене можна тягати мишкою.")

    # ----- персонаж і його пози -----
    def _load_character(self):
        self.photos: dict[str, ImageTk.PhotoImage] = {}
        cache: dict[Path, ImageTk.PhotoImage] = {}

        def load(path: Path):
            if path not in cache:
                img = Image.open(path).convert("RGBA")
                img.thumbnail((W, self.char_h))
                cache[path] = ImageTk.PhotoImage(img)
            return cache[path]

        fallback = [state_path("idle"), CHAR_IMAGE]
        for st in STATES:
            candidates = [state_path(st)] + ([state_path("speaking")] if st == "speaking2" else []) + fallback
            for path in candidates:
                if path.exists():
                    self.photos[st] = load(path)
                    break
        self._photo_cache = cache  # тримаємо посилання, інакше Tk «забуде» картинки
        if self.photos:
            self.set_state("idle")
        else:
            self.char.configure(text="(•ᴗ•)", font=("Segoe UI", 80), fg="white", bg="#444444")

    def set_state(self, state: str):
        if state in self.photos:
            self.char.configure(image=self.photos[state])

    def start_speaking(self, text: str):
        """Говорить: кадри speaking / speaking2 чергуються, тривалість залежить від довжини тексту."""
        self._stop_speaking()
        self._speak_until = time.time() + min(8.0, max(1.5, len(text) * 0.04))
        self._speak_tick(False)

    def _speak_tick(self, alt: bool):
        if time.time() >= self._speak_until:
            self._speak_job = None
            self.set_state("idle")
            return
        self.set_state("speaking2" if alt else "speaking")
        self._speak_job = self.root.after(280, lambda: self._speak_tick(not alt))

    def _stop_speaking(self):
        if self._speak_job is not None:
            self.root.after_cancel(self._speak_job)
            self._speak_job = None

    # ----- перетягування -----
    def _start_drag(self, e):
        self._drag = (e.x_root - self.x, e.y_root - self.y)

    def _on_drag(self, e):
        self.x, self.y = e.x_root - self._drag[0], e.y_root - self._drag[1]
        self.root.geometry(f"+{self.x}+{self.y}")

    # ----- рамка з текстом -----
    def _resize_bubble(self, new_h: int):
        """Змінює висоту рамки так, щоб низ вікна (персонаж і поле вводу) лишався на місці."""
        if new_h == self.bubble_h:
            return
        self.root.update_idletasks()
        old_total = self.root.winfo_reqheight()
        bottom = self.y + old_total
        self.bubble_h = new_h
        self.canvas.configure(height=new_h)
        self.root.update_idletasks()
        new_total = self.root.winfo_reqheight()
        self.y = bottom - new_total
        self.root.geometry(f"+{self.x}+{self.y}")

    def round_rect(self, x1, y1, x2, y2, r=18):
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
               x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        self.canvas.create_polygon(pts, smooth=True, fill="white", outline="black", width=3)

    def say(self, text: str, reply: bool = False):
        if reply:
            self.last_reply = text
        c, txt = self.canvas, self.txt
        c.delete("all")
        text = text if len(text) <= 4000 else text[:4000] + "…"
        pad, top, tail = 16, 6, 24
        max_w = W - 2 * pad - 40
        longest = max((self.bfont.measure(line) for line in text.split("\n")), default=0)
        tw = min(max_w, max(140, longest + 14))            # рамка підлаштовується під ширину тексту
        lh = self.bfont.metrics("linespace")

        txt.configure(state="normal")
        txt.delete("1.0", "end")
        txt.insert("1.0", text)
        txt.configure(state="disabled")

        cx = W // 2
        win = c.create_window(cx, top + pad, window=txt, anchor="n", width=tw, height=lh)
        self.root.update_idletasks()                       # віджет має з'явитись, щоб порахувати рядки
        res = txt.count("1.0", "end-1c", "displaylines")
        lines = res[0] if res else 1
        max_th = max(lh * 3, self.max_bubble_h - top - 2 * pad - tail - 8)
        th = min(lines * lh + 4, max_th)                   # довший текст прокручується колесом мишки
        c.itemconfigure(win, height=th)
        txt.yview_moveto(0)

        bx1, by1, bx2, by2 = cx - tw // 2 - pad, top, cx + tw // 2 + pad, top + th + 2 * pad
        c.create_polygon(cx - 16, by2 - 6, cx + 16, by2 - 6, cx, by2 + tail,
                         fill="white", outline="black", width=3)   # хвостик
        self.round_rect(bx1, by1, bx2, by2)
        self._resize_bubble(max(110, min(by2 + tail + 6, self.max_bubble_h)))

    # ----- виділення і копіювання -----
    def _select_all(self, _e=None):
        self.txt.tag_add("sel", "1.0", "end-1c")
        return "break"

    def _popup_menu(self, e):
        try:
            self.menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.menu.grab_release()

    def _to_clipboard(self, text: str):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()

    def copy_selection(self):
        try:
            sel = self.txt.get("sel.first", "sel.last")
        except tk.TclError:
            sel = ""
        if sel:
            self._to_clipboard(sel)

    def copy_all(self):
        self._to_clipboard(self.last_reply or self.txt.get("1.0", "end-1c"))

    # ----- решта -----
    def confirm(self, text: str) -> bool:
        """Викликається з потоку інструмента: просить головний потік показати діалог і чекає."""
        done, box = threading.Event(), {"ok": False}
        self.q.put(("confirm", (text, done, box)))
        done.wait()
        return box["ok"]

    def on_submit(self, _event=None):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self._stop_speaking()
        self.set_state("thinking")
        self.say("…думаю…")
        threading.Thread(target=lambda: self.q.put(("say", ask(text))), daemon=True).start()

    def toggle(self):
        if self.root.state() == "withdrawn":
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
            self.entry.focus_set()
        else:
            self.root.withdraw()

    def poll(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "toggle":
                    self.toggle()
                elif kind == "say":
                    self.say(payload, reply=True)
                    self.start_speaking(payload)
                elif kind == "confirm":
                    text, done, box = payload
                    self.root.deiconify()
                    box["ok"] = messagebox.askyesno("Ріас", text, parent=self.root)
                    done.set()
        except queue.Empty:
            pass
        self.root.after(100, self.poll)

    def run(self):
        keyboard.add_hotkey(HOTKEY, lambda: self.q.put(("toggle", None)))
        self.root.after(100, self.poll)
        self.root.mainloop()


if __name__ == "__main__":
    Ria().run()
